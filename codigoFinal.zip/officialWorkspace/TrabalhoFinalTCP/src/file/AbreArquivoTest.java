package file;

import org.junit.Test;

public class AbreArquivoTest {

	@Test
	public void test() {
//		AbreArquivo arquivo;
//		arquivo = new AbreArquivo("tcp.xml");
		
		
	}

}
