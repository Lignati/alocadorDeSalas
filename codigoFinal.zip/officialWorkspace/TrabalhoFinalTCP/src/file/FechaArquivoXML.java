package file;

public class FechaArquivoXML {

}
